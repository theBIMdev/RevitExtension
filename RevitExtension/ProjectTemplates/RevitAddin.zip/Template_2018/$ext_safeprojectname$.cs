﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    class Class1
    {
        private int $ext_safeprojectname$ = 0;
        private int $safeprojectname$ = 0;
    }
}
